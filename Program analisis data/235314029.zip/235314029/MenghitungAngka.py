def Angka():
    Total = 0
    for angka in range(11):
        print(angka)
        total =+ angka
    return total

Angka() 